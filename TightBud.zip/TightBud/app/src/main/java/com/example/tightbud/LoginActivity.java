package com.example.tightbud;

import android.content.Intent;
import android.os.Bundle;
import android.transition.Slide;
import android.transition.TransitionManager;
import android.view.Gravity;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class LoginActivity extends AppCompatActivity {

    private ConstraintLayout loginLayout, registerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginLayout = findViewById(R.id.loginLayout);
        registerLayout = findViewById(R.id.registerLayout);
    }

    public void toRegisterLayout(View view) {
        TransitionManager.beginDelayedTransition(findViewById(R.id.mainLayout), new Slide(Gravity.RIGHT));
        loginLayout.setVisibility(View.GONE);
        registerLayout.setVisibility(View.VISIBLE);
    }

    public void toLoginLayout(View view) {
        TransitionManager.beginDelayedTransition(findViewById(R.id.mainLayout), new Slide(Gravity.RIGHT));
        registerLayout.setVisibility(View.GONE);
        loginLayout.setVisibility(View.VISIBLE);
    }


    public void toForgotLayout(View view) {
        Intent intent= new Intent(this, ForgotActivity.class);
        startActivity(intent);
    }
}