package com.example.tightbud;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.transition.Slide;
import android.transition.TransitionManager;
import android.view.Gravity;
import android.view.View;

public class ForgotActivity extends AppCompatActivity {

    private ConstraintLayout confirmLayout, setNewPassLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot);

        confirmLayout = findViewById(R.id.confirmLayout);
        setNewPassLayout = findViewById((R.id.setNewPassLayout));
    }

    public void toLoginLayout(View view) {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    public void toSetNewPassLayout(View view) {
        TransitionManager.beginDelayedTransition(findViewById(R.id.mainLayout), new Slide(Gravity.LEFT));
        confirmLayout.setVisibility(View.GONE);
        setNewPassLayout.setVisibility(View.VISIBLE);
    }

    public void toConfirmLayout(View view) {
        TransitionManager.beginDelayedTransition(findViewById(R.id.mainLayout), new Slide(Gravity.LEFT));
        setNewPassLayout.setVisibility(View.GONE);
        confirmLayout.setVisibility(View.VISIBLE);
    }
}